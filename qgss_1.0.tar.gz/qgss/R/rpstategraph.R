#' RP-based quantile graph
#'
#' @param x Time series
#' @param q Quantile parameter (vector)
#' @param lags Lag order
#' @param nrand Number of graphs
#'
#' @returns LRP-based quantile graph (nrand graphs)
#' @export
#'
#' @examples x <- as.matrix(arima.sim(list(order = c(1,0,0), ar = 0.7), n = 2000))
#' @examples q=c(0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9)
#' @examples rpx=rpstategraph(x,q,1,100)
rpstategraph<-function(x,q,lags,nrand){
  n=length(q)+1
  rpx=array(0,dim=c(n,n,nrand))
  for(i in 1:nrand){
    rpx[,,i]=stategraph(sample(x),q,lags)
  }
  return(rpx)
}
