#' The function of converting a time series into a state sequence.
#'
#' @param s Time series
#' @param q Quantile parameter (vector)
#'
#' @returns State sequence
#' @export
#'
#' @examples x=rnorm(2000,0,1)
#' @examples q=c(0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9)
#' @examples s=series2state(x,q)
series2state<-function(s,q){
  n=length(q)
  qs=quantile(s,p=q)
  ss=matrix(0,c(n+1),1)
  ss[1:n]=as.matrix(qs)
  ss[c(n+1)]=max(s)
  ns=length(s)
  s01=matrix(0,ns,1)
  for(i in 1:ns){
    s01[i]=length(which(ss<s[i]))+1
  }
  return(s01)
}
