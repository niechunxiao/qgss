#' Calculate the baseline value of the i-th rpx matrix on the specified structure.
#'
#' @param rpx RP-based quantile graph
#' @param strumat  Specified structure
#' @param i The i-th RP-based quantile graph
#'
#' @returns Baseline value of the specified structure
#'
#'
#'
struselect<-function(rpx,strumat,i){
  rpxi=rpx[,,i]
  ns=dim(strumat)
  strurp=matrix(0,ns[1],1)
  for(i in 1:ns[1]){
    strurp[i]=rpxi[strumat[i,1],strumat[i,2]]
  }
  return(strurp)
}
