#' Structural significance analysis
#'
#' @param x Time series
#' @param rpg RP-based quantile graph
#' @param q Quantile parameter (vector)
#' @param lags Lag order
#' @param nrand Number of graphs
#' @param strumat Specified structure
#'
#' @returns A list that includes the results of structural significance analysis.
#' @export
#'
#' @examples x <- as.matrix(arima.sim(list(order = c(1,0,0), ar = 0.7), n = 2000))
#' @examples q=c(0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9)
#' @examples rpx=rpstategraph(x,q,1,100)
#' @examples struc=matrix(0,4,2)
#' @examples struc[1,]=c(1,1)
#' @examples struc[2,]=c(1,2)
#' @examples struc[3,]=c(2,1)
#' @examples struc[4,]=c(2,2)
#' @examples ss=strurpsurrogates(x, rpx, q, 1, 100, struc)
#'
strurpsurrogates<-function(x,rpg,q,lags,nrand,strumat){

  xnet=stategraph(x,q,lags)
  nd=dim(strumat)
  strurpx=array(0,dim=c(nd[1],1,nrand))
  for(i in 1:nrand){
    strurpx[,,i]=struselect(rpg,strumat,i)
  }

  rpavep=matrix(0,nrand,1)
  for(i in 1:nrand){
    rpavep[i]=sum(strurpx[,,i])/nd[1]
  }


  strup=matrix(0,nd[1],1)
  for(i in 1:nd[1]){
    strup[i,]=xnet[strumat[i,1],strumat[i,2]]
  }
  avep=sum(strup)/nd[1]

  zscore=(avep-mean(rpavep))/sd(rpavep)

  output=list(quantileg=xnet,strup=strup,rpavep=rpavep,avep=avep,zscore=zscore)
  return(output)
}
