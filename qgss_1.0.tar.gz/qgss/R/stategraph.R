#' Quantile graph
#'
#' @param x Time series
#' @param q Quantile parameter (vector)
#' @param lags Lag order
#'
#' @returns A weighted adjacency matrix
#' @export
#'
#' @examples q=c(0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9)
#' @examples x=rnorm(2000,0,1)
#' @examples g=stategraph(x,q,1)
stategraph<-function(x,q,lags){
  n=length(x)
  x0=series2state(x,q)
  x1=x0[1:c(n-lags)]
  x2=x0[c(lags+1):n]
  xx=cbind(x1,x2)
  nq=length(q)+1
  smat=matrix(0,nq,nq)
  for(i in 1:nq){
    for(j in 1:nq){
      smat[i,j]=length(intersect(which(xx[,1]==i),which(xx[,2]==j)))
    }
  }
  sp=matrix(0,nq,nq)
  for(i in 1:nq){
    sp[i,]=smat[i,]/sum(smat[i,])
  }
  return(sp)
}
